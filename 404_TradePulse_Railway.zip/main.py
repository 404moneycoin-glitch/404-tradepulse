import os, time, requests

TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
CHAT_ID = os.environ["TELEGRAM_CHAT_ID"]
POLL_SECONDS = int(os.getenv("POLL_SECONDS", "300"))
COINS = {"bitcoin":"BTC","solana":"SOL","ripple":"XRP"}
last = {}

def send(text):
    r = requests.post(
        f"https://api.telegram.org/bot{TOKEN}/sendMessage",
        json={"chat_id": CHAT_ID, "text": text},
        timeout=20,
    )
    r.raise_for_status()

send("🟢 404 TradePulse is online.\nScan. Analyze. Alert.")

while True:
    try:
        r = requests.get(
            "https://api.coingecko.com/api/v3/simple/price",
            params={
                "ids": ",".join(COINS),
                "vs_currencies": "usd",
                "include_24hr_change": "true",
            },
            timeout=20,
        )
        r.raise_for_status()
        data = r.json()

        for coin, symbol in COINS.items():
            price = data[coin]["usd"]
            change = data[coin].get("usd_24h_change", 0)
            signal = "UP" if change >= 3 else "DOWN" if change <= -3 else "NEUTRAL"

            if signal != "NEUTRAL" and last.get(symbol) != signal:
                icon = "🟢" if signal == "UP" else "🔴"
                send(
                    f"{icon} 404 TradePulse Alert\n"
                    f"{symbol}: ${price:,.4f}\n"
                    f"24h change: {change:+.2f}%\n"
                    f"Signal: {signal}\n\n"
                    "Market alert only — not financial advice."
                )
            last[symbol] = signal

    except Exception as e:
        print("Error:", e, flush=True)

    time.sleep(POLL_SECONDS)
