# 404 TradePulse — Railway
Required Railway variables:
- TELEGRAM_BOT_TOKEN
- TELEGRAM_CHAT_ID

Optional:
- POLL_SECONDS (default 300)

No secrets are stored in this repository.
